# To-Do-List-Django-
It's a list where you can list everything that you have to do, with the most important tasks at the top of the list, and the least important tasks at the bottom. 
